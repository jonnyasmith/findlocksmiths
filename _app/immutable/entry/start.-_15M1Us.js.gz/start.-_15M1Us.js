import{l as o,a as r}from"../chunks/SJq9Ra-t.js";export{o as load_css,r as start};
